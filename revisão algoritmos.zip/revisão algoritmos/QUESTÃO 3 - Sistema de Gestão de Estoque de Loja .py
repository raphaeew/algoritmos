import os

produtos = []

ARQUIVO = "estoque.txt"


def adicionar_produto():
    print("=== Adicionar Produto ===")
    
    nome = input("Nome do produto: ")
    if nome == "":
        print("Erro: Nome não pode estar vazio!\n")
        return
    
    categoria = input("Categoria: ")
    if categoria == "":
        print("Erro: Categoria não pode estar vazia!\n")
        return
    
    while True:
        try:
            preco = float(input("Preço: R$ "))
            if preco < 0:
                print("Erro: Preço não pode ser negativo!")
                continue
            break
        except ValueError:
            print("Erro: Digite um número válido!")
    
    while True:
        try:
            quantidade = int(input("Quantidade: "))
            if quantidade < 0:
                print("Erro: Quantidade não pode ser negativa!")
                continue
            break
        except ValueError:
            print("Erro: Digite um número inteiro!")
    
    produto = {}
    produto["nome"] = nome
    produto["categoria"] = categoria
    produto["preco"] = preco
    produto["quantidade"] = quantidade
    
    produtos.append(produto)
    print("Produto adicionado com sucesso!\n")


def atualizar_quantidade():
    print("=== Atualizar Quantidade ===")
    
    if len(produtos) == 0:
        print("Nenhum produto cadastrado!\n")
        return
    
    listar_produtos()
    
    try:
        numero = int(input("Digite o número do produto: "))
        if numero < 1 or numero > len(produtos):
            print("Produto não encontrado!\n")
            return
    except ValueError:
        print("Digite um número válido!\n")
        return
    
    indice = numero - 1
    produto_selecionado = produtos[indice]
    
    print("\n1. Aumentar quantidade")
    print("2. Reduzir quantidade")
    opcao = input("Escolha: ")
    
    try:
        valor = int(input("Quantidade: "))
        if valor < 0:
            print("Valor deve ser positivo!\n")
            return
    except ValueError:
        print("Digite um número inteiro!\n")
        return
    
    if opcao == "1":
        produto_selecionado["quantidade"] = produto_selecionado["quantidade"] + valor
        print(f"Quantidade aumentada para {produto_selecionado['quantidade']}!\n")
    elif opcao == "2":
        if valor > produto_selecionado["quantidade"]:
            print("Quantidade insuficiente!\n")
        else:
            produto_selecionado["quantidade"] = produto_selecionado["quantidade"] - valor
            print(f"Quantidade reduzida para {produto_selecionado['quantidade']}!\n")
    else:
        print("Opção inválida!\n")


def listar_produtos():
    if len(produtos) == 0:
        print("Nenhum produto cadastrado!\n")
        return
    
    print("\n--- Produtos ---")
    for i in range(len(produtos)):
        p = produtos[i]
        numero = i + 1
        print(f"{numero}. {p['nome']} | {p['categoria']} | R$ {p['preco']:.2f} | Qtd: {p['quantidade']}")
    print()


def ordenar_produtos():
    print("=== Ordenar Produtos ===")
    
    if len(produtos) == 0:
        print("Nenhum produto cadastrado!\n")
        return
    
    print("Ordenar por:")
    print("1. Preço")
    print("2. Quantidade")
    opcao_campo = input("Escolha: ")
    
    print("\n1. Crescente")
    print("2. Decrescente")
    opcao_ordem = input("Escolha: ")
    
    lista_copia = []
    for p in produtos:
        lista_copia.append(p)
    
    if opcao_campo == "1":
        for i in range(len(lista_copia)):
            for j in range(i + 1, len(lista_copia)):
                if opcao_ordem == "1":
                    if lista_copia[i]["preco"] > lista_copia[j]["preco"]:
                        aux = lista_copia[i]
                        lista_copia[i] = lista_copia[j]
                        lista_copia[j] = aux
                else:
                    if lista_copia[i]["preco"] < lista_copia[j]["preco"]:
                        aux = lista_copia[i]
                        lista_copia[i] = lista_copia[j]
                        lista_copia[j] = aux
    
    elif opcao_campo == "2":
        for i in range(len(lista_copia)):
            for j in range(i + 1, len(lista_copia)):
                if opcao_ordem == "1":
                    if lista_copia[i]["quantidade"] > lista_copia[j]["quantidade"]:
                        aux = lista_copia[i]
                        lista_copia[i] = lista_copia[j]
                        lista_copia[j] = aux
                else:
                    if lista_copia[i]["quantidade"] < lista_copia[j]["quantidade"]:
                        aux = lista_copia[i]
                        lista_copia[i] = lista_copia[j]
                        lista_copia[j] = aux
    else:
        print("Opção inválida!\n")
        return
    
    print("\n--- Produtos Ordenados ---")
    for i in range(len(lista_copia)):
        p = lista_copia[i]
        numero = i + 1
        print(f"{numero}. {p['nome']} | {p['categoria']} | R$ {p['preco']:.2f} | Qtd: {p['quantidade']}")
    print()


def salvar_estoque():
    print("=== Salvar Estoque ===")
    
    if len(produtos) == 0:
        print("Nenhum produto para salvar!\n")
        return
    
    try:
        arquivo = open(ARQUIVO, "w")
        
        for p in produtos:
            linha = p["nome"] + "," + p["categoria"] + "," + str(p["preco"]) + "," + str(p["quantidade"])
            arquivo.write(linha + "\n")
        
        arquivo.close()
        print(f"Dados salvos em '{ARQUIVO}'.\n")
    
    except IOError:
        print("Erro: Problema ao salvar o arquivo!\n")
    except PermissionError:
        print("Erro: Sem permissão para salvar!\n")


def carregar_estoque():
    print("=== Carregar Estoque ===")
    
    global produtos
    
    if not os.path.exists(ARQUIVO):
        print(f"Arquivo '{ARQUIVO}' não encontrado.\n")
        return
    
    try:
        produtos = []
        
        arquivo = open(ARQUIVO, "r")
        linhas = arquivo.readlines()
        arquivo.close()
        
        for linha in linhas:
            linha = linha.strip()
            
            if linha != "":
                partes = linha.split(",")
                
                if len(partes) == 4:
                    try:
                        produto = {}
                        produto["nome"] = partes[0]
                        produto["categoria"] = partes[1]
                        produto["preco"] = float(partes[2])
                        produto["quantidade"] = int(partes[3])
                        produtos.append(produto)
                    except ValueError:
                        print(f"Aviso: Linha com dados inválidos: {linha}")
        
        print(f"Estoque carregado ({len(produtos)} produtos).\n")
    
    except IOError:
        print("Erro: Problema ao ler o arquivo!\n")
    except PermissionError:
        print("Erro: Sem permissão para ler!\n")


def menu_principal():
    print("\n" + "="*50)
    print("Bem-vindo ao Sistema de Gestão de Estoque!")
    print("="*50 + "\n")
    
    while True:
        print("Escolha uma opção:")
        print("1. Adicionar produto")
        print("2. Atualizar quantidade")
        print("3. Listar produtos")
        print("4. Ordenar produtos")
        print("5. Salvar dados em arquivo")
        print("6. Carregar dados do arquivo")
        print("7. Sair")
        print()
        
        opcao = input("> ")
        print()
        
        if opcao == "1":
            adicionar_produto()
        elif opcao == "2":
            atualizar_quantidade()
        elif opcao == "3":
            listar_produtos()
        elif opcao == "4":
            ordenar_produtos()
        elif opcao == "5":
            salvar_estoque()
        elif opcao == "6":
            carregar_estoque()
        elif opcao == "7":
            if len(produtos) > 0:
                resposta = input("Deseja salvar o estoque antes de sair? (S/N): ")
                if resposta.upper() == "S":
                    salvar_estoque()
            print("Até logo!\n")
            break
        else:
            print("Opção inválida!\n")


if __name__ == "__main__":
    menu_principal()

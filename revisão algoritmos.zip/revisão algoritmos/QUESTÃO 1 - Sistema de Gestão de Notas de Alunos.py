class SistemaNotas:
    def __init__(self, arquivo="alunos.txt"):
        self.arquivo = arquivo
        self.alunos = []
        self.carregar_dados()
    
    def adicionar_aluno(self, nome):
        if any(aluno["nome"].lower() == nome.lower() for aluno in self.alunos):
            print(f"Aluno '{nome}' já existe!")
            return
        self.alunos.append({"nome": nome, "notas": [], "media": 0.0})
        print(f"Aluno '{nome}' adicionado!")
    
    def registrar_nota(self, nome, nota):
        try:
            nota = float(nota)
            if not (0 <= nota <= 10):
                print("Nota deve estar entre 0 e 10!")
                return
        except ValueError:
            print("Nota inválida!")
            return
        
        aluno = next((aluno for aluno in self.alunos if aluno["nome"].lower() == nome.lower()), None)
        if not aluno:
            print(f"Aluno '{nome}' não encontrado!")
            return
        
        aluno["notas"].append(nota)
        aluno["media"] = sum(aluno["notas"]) / len(aluno["notas"])
        print(f"Nota {nota} registrada! Média: {aluno['media']:.2f}")
    
    def calcular_media_turma(self):
        todas_notas = [nota for aluno in self.alunos for nota in aluno["notas"]]
        if not todas_notas:
            print("Nenhuma nota registrada!")
            return 0
        return sum(todas_notas) / len(todas_notas)
    
    def listar_alunos(self):
        if not self.alunos:
            print("Nenhum aluno cadastrado!")
            return
        print("\n--- ALUNOS ---")
        for aluno in self.alunos:
            notas_fmt = ", ".join(str(nota) for nota in aluno['notas'])
            print(f"Nome do aluno: {aluno['nome']}")
            print(f"Notas: {notas_fmt}")
        print()
    
    def exibir_relatorio(self):
        if not self.alunos:
            print("Nenhum aluno cadastrado!")
            return
        for aluno in self.alunos:
            notas_fmt = ", ".join(str(nota) for nota in aluno['notas'])
            print(f"Nome do aluno: {aluno['nome']}")
            print(f"Notas: {notas_fmt}")
        alunos_ordenados = sorted(self.alunos, key=lambda aluno: aluno['media'], reverse=True)
        print("\nAlunos ordenados por média:")
        for aluno in alunos_ordenados:
            if aluno['notas']:
                print(f"{aluno['nome']} - Média: {aluno['media']:.2f}")
        print(f"\nOs dados foram salvos no arquivo '{self.arquivo}'.")
    
    def salvar_dados(self):
        try:
            with open(self.arquivo, 'w', encoding='utf-8') as f:
                for aluno in self.alunos:
                    notas_str = ','.join(str(nota) for nota in aluno['notas'])
                    f.write(f"{aluno['nome']}|{notas_str}|{aluno['media']:.2f}\n")
            print("Dados salvos!")
        except Exception as e:
            print(f"Erro ao salvar: {e}")
    
    def carregar_dados(self):
        try:
            with open(self.arquivo, 'r', encoding='utf-8') as f:
                for linha in f:
                    partes = linha.strip().split('|')
                    if len(partes) == 3:
                        nome, notas_str, media = partes
                        notas = [float(n) for n in notas_str.split(',')] if notas_str else []
                        self.alunos.append({"nome": nome, "notas": notas, "media": float(media)})
        except FileNotFoundError:
            self.alunos = []
        except Exception as e:
            print(f"Erro ao carregar: {e}")
            self.alunos = []

def menu():
    sistema = SistemaNotas()
    while True:
        print("\n1-Add aluno  2-Add nota  3-Listar  4-Média turma  5-Relatório  6-Salvar  7-Sair")
        opcao = input("Opção: ").strip()
        
        if opcao == "1":
            sistema.adicionar_aluno(input("Nome: "))
        elif opcao == "2":
            sistema.registrar_nota(input("Nome: "), input("Nota: "))
        elif opcao == "3":
            sistema.listar_alunos()
        elif opcao == "4":
            media = sistema.calcular_media_turma()
            if media > 0:
                print(f"Média da turma: {media:.2f}")
        elif opcao == "5":
            sistema.exibir_relatorio()
        elif opcao == "6":
            sistema.salvar_dados()
        elif opcao == "7":
            if input("Salvar antes? (s/n): ").lower() == "s":
                sistema.salvar_dados()
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    menu()


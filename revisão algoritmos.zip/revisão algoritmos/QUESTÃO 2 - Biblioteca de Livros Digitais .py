class Biblioteca:
    def __init__(self, arquivo="biblioteca.txt"):
        self.arquivo = arquivo
        self.livros = []
        self.carregar_livros()
    
    def adicionar_livro(self):
        titulo = input("Título do livro: ").strip()
        autor = input("Autor: ").strip()
        
        while True:
            try:
                ano = int(input("Ano de publicação: "))
                if ano <= 0:
                    print("Ano deve ser positivo!")
                    continue
                break
            except ValueError:
                print("Ano inválido! Digite um número inteiro.")
        
        while True:
            try:
                paginas = int(input("Número de páginas: "))
                if paginas <= 0:
                    print("Páginas deve ser positivo!")
                    continue
                break
            except ValueError:
                print("Páginas inválido! Digite um número inteiro.")
        
        livro = {"titulo": titulo, "autor": autor, "ano": ano, "paginas": paginas}
        self.livros.append(livro)
        print("Livro adicionado com sucesso!")
    
    def listar_livros(self):
        if not self.livros:
            print("Nenhum livro cadastrado!")
            return
        print("\n--- LIVROS CADASTRADOS ---")
        for i, livro in enumerate(self.livros, 1):
            print(f"{i}. {livro['titulo']} - {livro['autor']} ({livro['ano']}) - {livro['paginas']} páginas")
        print()
    
    def ordenar_livros(self):
        if not self.livros:
            print("Nenhum livro cadastrado!")
            return
        
        print("Ordenar por: 1-Ano  2-Páginas")
        opcao = input("Escolha: ").strip()
        
        print("Ordem: 1-Crescente  2-Decrescente")
        ordem = input("Escolha: ").strip()
        
        reverse = ordem == "2"
        
        if opcao == "1":
            livros_ord = sorted(self.livros, key=lambda x: x['ano'], reverse=reverse)
            print("\n--- LIVROS ORDENADOS POR ANO ---")
        elif opcao == "2":
            livros_ord = sorted(self.livros, key=lambda x: x['paginas'], reverse=reverse)
            print("\n--- LIVROS ORDENADOS POR PÁGINAS ---")
        else:
            print("Opção inválida!")
            return
        
        for i, livro in enumerate(livros_ord, 1):
            print(f"{i}. {livro['titulo']} - {livro['autor']} ({livro['ano']}) - {livro['paginas']} páginas")
        print()
    
    def salvar_livros(self):
        try:
            with open(self.arquivo, 'w', encoding='utf-8') as f:
                for livro in self.livros:
                    f.write(f"{livro['titulo']},{livro['autor']},{livro['ano']},{livro['paginas']}\n")
            print(f"Os dados foram salvos no arquivo '{self.arquivo}'.")
        except IOError as e:
            print(f"Erro ao salvar arquivo: {e}")
        except Exception as e:
            print(f"Erro inesperado: {e}")
    
    def carregar_livros(self):
        try:
            with open(self.arquivo, 'r', encoding='utf-8') as f:
                for linha in f:
                    partes = linha.strip().split(',')
                    if len(partes) == 4:
                        try:
                            livro = {
                                "titulo": partes[0],
                                "autor": partes[1],
                                "ano": int(partes[2]),
                                "paginas": int(partes[3])
                            }
                            self.livros.append(livro)
                        except ValueError:
                            print(f"Erro ao carregar linha: {linha}")
        except FileNotFoundError:
            pass
        except IOError as e:
            print(f"Erro ao abrir arquivo: {e}")
        except Exception as e:
            print(f"Erro inesperado ao carregar: {e}")

def menu():
    print("Bem-vindo à Biblioteca Digital!")
    biblioteca = Biblioteca()
    
    while True:
        print("\nEscolha uma opção:")
        print("1. Adicionar livro")
        print("2. Listar livros")
        print("3. Ordenar livros")
        print("4. Salvar dados em arquivo")
        print("5. Carregar dados do arquivo")
        print("6. Sair")
        
        opcao = input("> ").strip()
        
        if opcao == "1":
            biblioteca.adicionar_livro()
        elif opcao == "2":
            biblioteca.listar_livros()
        elif opcao == "3":
            biblioteca.ordenar_livros()
        elif opcao == "4":
            biblioteca.salvar_livros()
        elif opcao == "5":
            biblioteca.carregar_livros()
            print("Dados carregados!")
        elif opcao == "6":
            resposta = input("Deseja salvar os dados antes de sair? (S/N): ").upper()
            if resposta == "S":
                biblioteca.salvar_livros()
            break
        else:
            print("Opção inválida!")

if __name__ == "__main__":
    menu()
